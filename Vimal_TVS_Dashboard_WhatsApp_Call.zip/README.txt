
Vimal TVS Agency – Button Dashboard + WhatsApp + Call Combo
===========================================================

FEATURES
- Button dashboard (Run Calls)
- Shows service-due list
- Sends WhatsApp message first
- Then Exotel auto call

FILES
- dashboard.py
- service_data.xlsx
- whatsapp_template.txt
- requirements.txt

RUN
pip install -r requirements.txt
streamlit run dashboard.py
