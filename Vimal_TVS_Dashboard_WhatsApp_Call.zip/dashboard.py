
import streamlit as st
import pandas as pd
from datetime import datetime
import requests

st.set_page_config(page_title="Vimal TVS Service Dashboard")

st.title("🔧 Vimal TVS Agency – Service Dashboard")

df = pd.read_excel("service_data.xlsx")
df['last_service_date'] = pd.to_datetime(df['last_service_date'])
df['days'] = (datetime.today() - df['last_service_date']).dt.days

due = df[(df['days'] >= 30) | (df['free_service'] == 'Yes') | (df['km_run'] >= 2500)]

st.subheader("📋 Service Due Customers")
st.dataframe(due)

if st.button("📞 Start Service Calls"):
    st.success("Calls process started (Exotel integration)")
